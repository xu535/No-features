package border;

//导入
import arc.*;
import arc.util.*;
import mindustry.*;
import mindustry.content.*;
import mindustry.game.EventType.*;
import mindustry.gen.*;
import mindustry.mod.*;
import mindustry.ui.dialogs.*;

import border.contents.items.*;
import border.contents.liquids.*;
import border.contents.bullets.*;
import border.contents.blocks.turrets.*;
import border.contents.blocks.*;


public class Border extends Mod{
	

	
    public Border(){
        Log.info("Loaded ExampleJavaMod constructor.");
    }

    @Override
    public void loadContent(){
		Log.info("Loading some example content.");
		new BOItems().load();
                new BOLiquids().load();
                new BOBullets().load();
		new BOFactories().load();
                new BOOreblocks().load();
                new BOTurrets().load();
                
    }
	
}
