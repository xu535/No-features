package border.contents.bullets;
 
import arc.audio.*;
import arc.math.geom.*;
import arc.graphics.*;
import arc.graphics.g2d.*;
import arc.math.*;
import arc.util.*;
import arc.struct.*;
import arc.util.ArcAnnotate.*;
import mindustry.entities.*;
import mindustry.entities.bullet.*;
import mindustry.io.*;
import mindustry.content.*;
import mindustry.ctype.*;
import mindustry.game.*;
import mindustry.gen.*;
import mindustry.graphics.*;
import mindustry.type.*;
import mindustry.world.*;

import static mindustry.Vars.*;
 
public class BOBullets implements ContentList {
	public static
	BulletType superElectromagnetic;
 
	@Override
	public void load() {
	superElectromagnetic = new BasicBulletType(5f, 12f){

            {
                hitEffect = new Effect(12f, e -> {
                Draw.color(Color.valueOf("#F0FFFF"),Color.valueOf("#9370DB"),e.fin());
		Lines.stroke(e.fout() * 1.7f);
		Lines.square(e.x, e.y, 2f + e.fout() * 6f);
                Fill.square(e.x,e.y,6f * e.fout(),90);
                Fill.square(e.x,e.y,6f * e.fout(),135);
				});
                smokeEffect = hitEffect;
                despawnEffect = Fx.none;
                hitSize = 4;
                drawSize = 420f;
                lifetime = 300f;
                pierce = true;
            }
            @Override
            public void update(Bullet b){
           if(b.timer.get(1, 5f)){
           new Effect(25f, e -> {
           Draw.color(Color.valueOf("#F0FFFF"),Color.valueOf("#9370DB"),e.fin());
           Lines.stroke(e.fout() * 3f);
           Lines.circle(e.x, e.y, e.fin() * 11f);
           Drawf.tri(e.x, e.y, 5f, 8f, 180);
           Drawf.tri(e.x, e.y, 5f, 8f, 0);
	   Drawf.tri(e.x, e.y, 5f, 8f, 90);
	   Drawf.tri(e.x, e.y, 5f, 8f, 270);
				}).at(b);
        }
           for (int num = 0; num < 3; num ++) {
		Lightning.create(b.team(), Color.valueOf("#F0FFFF"), 50, b.x, b.y, Mathf.random(360), Mathf.random(3, 6));
	   }
            }
          public void hit(Bullet b, float hitx, float hity){
           new Effect(120f, e -> {
                for (int num = 0; num < 3; num ++) {
                float offset = Mathf.random(5, 10);
                Draw.color(Color.valueOf("#F0FFFF"),Color.valueOf("#9370DB"),e.fin());
		Lines.stroke(e.fout() * 1.7f);
		Lines.square(e.x+offset, e.y+offset, 2f + e.fout() * 6f);
                Fill.square(e.x+offset,e.y+offset,6f * e.fout(),90);
                Fill.square(e.x+offset,e.y+offset,6f * e.fout(),135);
                }
				}).at(b);
          }

        @Override
        public void draw(Bullet b){
        Draw.color(Color.valueOf("#F0FFFF"),Color.valueOf("#9370DB"),b.fin());
        Lines.stroke(b.fout() * 3f);
           Lines.circle(b.x, b.y, b.fin() * 11f);
           Drawf.tri(b.x, b.y, 5f, 8f, 180);
           Drawf.tri(b.x, b.y, 5f, 8f, 0);
	   Drawf.tri(b.x, b.y, 5f, 8f, 90);
	   Drawf.tri(b.x, b.y, 5f, 8f, 270);
        }
        };
}
}
