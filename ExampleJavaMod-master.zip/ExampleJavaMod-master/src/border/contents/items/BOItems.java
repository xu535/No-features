package border.contents.items;

import arc.graphics.*;
import mindustry.ctype.*;
import mindustry.type.*;

public class BOItems implements ContentList{
	
	//Load Mod Items
	
	public static Item 
	sinkStarAlloy, sporeAlloy, FallAlloy, Deepfragment, DeepIron, NaturalAlloy;
	
	@Override
	public void load(){
		sinkStarAlloy = new Item("sinkstar-alloy", Color.valueOf("#F0FFFF"));
		sporeAlloy = new Item("spore-alloy", Color.valueOf("#9400D3")){{
                flammability = 1f;
                }};
                FallAlloy = new Item("RX-024fall-alloy", Color.valueOf("#ffb380"));
                Deepfragment = new Item("deep-fragment", Color.valueOf("#808080"));
                DeepIron = new Item("N-13-deep-iron", Color.valueOf("#808080"));
                NaturalAlloy = new Item("LE-64natural-alloy", Color.valueOf("#32CD32"));

	}
	
}
