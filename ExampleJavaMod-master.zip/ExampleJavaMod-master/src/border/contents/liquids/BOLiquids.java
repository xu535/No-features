package border.contents.liquids;
 
import arc.graphics.*;
import mindustry.ctype.*;
import mindustry.type.*;
 
public class BOLiquids implements ContentList{
	
	//Load Mod Liquids
	
	public static Liquid 
	psioniCpowerLiquid,
	highCombustionLiquid,
	quickFreezingLiquid;
	
	@Override
	public void load(){
	        //灵能液
		psioniCpowerLiquid = new Liquid("psioni-cpower-liquid", Color.valueOf("#00BFFF")){{
			temperature = 0f;
                        viscosity = 2f;
                        flammability = 0f;
                        explosiveness = 10f;
                        heatCapacity = 2f;
		}};
		
		//高燃液
		highCombustionLiquid = new Liquid("high-combustion-liquid", Color.valueOf("#FF8C00")){{
			heatCapacity = 0f;
			explosiveness = 10f;
                        temperature = 10f;
			viscosity = 2f;
                        flammability = 8f;
			lightColor = Color.valueOf("#FF8C00");
		}};
                //急冻液
		quickFreezingLiquid = new Liquid("quick-freezing-liquid", Color.valueOf("#00BFFF")){{
			heatCapacity = 3f;
			explosiveness = 0f;
			viscosity = 0.5f;
			temperature = 0f;
			lightColor = Color.valueOf("#00BFFF");
		}};
	}
}
