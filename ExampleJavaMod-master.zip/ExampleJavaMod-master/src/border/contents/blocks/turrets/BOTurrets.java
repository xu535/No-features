package border.contents.blocks.turrets;

import arc.*;
import arc.math.*;
import arc.graphics.*;
import arc.graphics.g2d.*;
import mindustry.ctype.*;
import mindustry.content.*;
import mindustry.world.blocks.defense.turrets.*;
import mindustry.entities.*;
import mindustry.entities.bullet.*;
import mindustry.gen.*;
import mindustry.graphics.*;
import mindustry.type.*;
import mindustry.world.*;
import mindustry.world.blocks.*;
import mindustry.world.blocks.campaign.*;
import mindustry.world.blocks.defense.*;
import mindustry.world.blocks.defense.turrets.*;
import mindustry.world.blocks.distribution.*;
import mindustry.world.blocks.environment.*;
import mindustry.world.blocks.experimental.*;
import mindustry.world.blocks.legacy.*;
import mindustry.world.blocks.liquid.*;
import mindustry.world.blocks.logic.*;
import mindustry.world.blocks.power.*;
import mindustry.world.blocks.production.*;
import mindustry.world.blocks.sandbox.*;
import mindustry.world.blocks.storage.*;
import mindustry.world.blocks.units.*;
import mindustry.world.consumers.*;
import mindustry.world.draw.*;
import mindustry.world.meta.*;

import border.contents.items.*;
import border.contents.bullets.*;

import static mindustry.type.ItemStack.*;

public class BOTurrets implements ContentList {

  // Load Mod Turrets
  public static Block superElectromagneticTurret;

  @Override
  public void load() {
    superElectromagneticTurret = new LaserTurret("LGT-superElectromagneticTurret-015"){
			{
				requirements(Category.turret, with(BOItems.sinkStarAlloy, 85, Items.graphite, 95, BOItems.sporeAlloy, 60));
				shootType = BOBullets.superElectromagnetic;
				baseRegion = Core.atlas.find("border-block-" + size);
				size = 3;
				range = 360;
				reloadTime = 15f;
				restitution = 0.03f;
				inaccuracy = 13f;
				cooldown = 0.03f;
				recoilAmount = 3f;
				shootShake = 1f;
				burstSpacing = 3f;
				shots = 1;
				ammoUseEffect = Fx.shellEjectBig;
				health = 300 * size * size;
				shootSound = Sounds.laser;
			}
		};
  }
}
