package border.contents.blocks;

import arc.*;
import arc.math.*;
import arc.graphics.*;
import arc.graphics.g2d.*;
import mindustry.ctype.*;
import mindustry.content.*;

import mindustry.entities.*;
import mindustry.entities.bullet.*;
import mindustry.gen.*;
import mindustry.graphics.*;
import mindustry.type.*;
import mindustry.world.*;
import mindustry.world.blocks.*;
import mindustry.world.blocks.campaign.*;
import mindustry.world.blocks.defense.*;
import mindustry.world.blocks.defense.turrets.*;
import mindustry.world.blocks.distribution.*;
import mindustry.world.blocks.environment.*;
import mindustry.world.blocks.experimental.*;
import mindustry.world.blocks.legacy.*;
import mindustry.world.blocks.liquid.*;
import mindustry.world.blocks.logic.*;
import mindustry.world.blocks.power.*;
import mindustry.world.blocks.production.*;
import mindustry.world.blocks.sandbox.*;
import mindustry.world.blocks.storage.*;
import mindustry.world.blocks.units.*;
import mindustry.world.consumers.*;
import mindustry.world.draw.*;
import mindustry.world.meta.*;

import border.contents.items.*;
import border.contents.blocks.drawers.*;

import static mindustry.type.ItemStack.*;
import static mindustry.Vars.*;

public class BOFactories implements ContentList {

	//Load Mod Factories

	public static Block
	sporeCompressor, refining;

	@Override
	public void load() {
		sporeCompressor = new GenericCrafter("spore-compressor") {
			{
				requirements(Category.crafting, with(Items.silicon, 25, Items.lead, 95, Items.graphite, 25, Items.titanium, 85));
				hasItems = hasPower = true;
				craftTime = 60f;
				outputItem = new ItemStack(BOItems.sporeAlloy, 1);
				size = 3;
				health = 380;
				craftEffect = Fx.shockwave;
                                updateEffect = new Effect(25f, e -> {
                                        Draw.color(Color.valueOf("#F0FFFF"),Color.valueOf("#9370DB"),e.fin());
					Lines.stroke(e.fout() * 1.7f);
					Lines.square(e.x, e.y, 2f + e.fout() * 6f);
                                        Fill.square(e.x,e.y,6f * e.fout(),90);
                                        Fill.square(e.x,e.y,6f * e.fout(),135);
                                        Lines.stroke(e.fout() * 3f);
                                        Lines.circle(e.x, e.y, e.fin() * 11f);
				});
				drawer = new DrawBlock();
				consumes.power(3f);
				consumes.items(new ItemStack(Items.titanium, 2), new ItemStack(Items.sporePod, 1));
			}
		};

		refining = new GenericCrafter("refining") {
			{
				requirements(Category.crafting, with(Items.silicon, 10, Items.lead, 35, Items.titanium, 30));
				hasItems = hasPower = true;
				craftTime = 45f;
				outputItem = new ItemStack(BOItems.DeepIron, 1);
				size = 2;
				health = 60;
				craftEffect = Fx.smeltsmoke;
				updateEffect = new Effect(25f, e -> {
                                        Draw.color(Color.valueOf("#F0FFFF"),Color.valueOf("#9370DB"),e.fin());
                                        Lines.stroke(e.fout() * 3f);
                                        Lines.circle(e.x, e.y, e.fin() * 11f);
                                        Drawf.tri(e.x, e.y, 5f, 8f, 180);
		                        Drawf.tri(e.x, e.y, 5f, 8f, 0);
		                        Drawf.tri(e.x, e.y, 5f, 8f, 90);
		                        Drawf.tri(e.x, e.y, 5f, 8f, 270);
				});
				drawer = new DrawBlock();
				consumes.power(1.5f);
				consumes.item(BOItems.Deepfragment, 2);
			}
		};
	}
}
